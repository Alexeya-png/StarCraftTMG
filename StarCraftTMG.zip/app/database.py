from __future__ import annotations

import atexit
import copy
import math
import os
import re
import threading
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Generator

import psycopg2
from dotenv import load_dotenv
from psycopg2.extras import RealDictCursor
from psycopg2.pool import ThreadedConnectionPool

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
FLAGS_DIR = BASE_DIR / 'static' / 'Flags'
ALLOWED_FLAG_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.svg', '.webp'}


class DatabaseConfigError(RuntimeError):
    pass


REQUIRED_ENV_VARS = ('user', 'password', 'host', 'port', 'dbname')

RACE_LABELS = {
    'Терран': 'Terran',
    'Протосс': 'Protoss',
    'Зерг': 'Zerg',
    'Terran': 'Terran',
    'Protoss': 'Protoss',
    'Zerg': 'Zerg',
}

COUNTRY_ALIASES = {
    'ua': 'ua',
    'ukraine': 'ua',
    'украина': 'ua',
    'ukraina': 'ua',
    'ukrayina': 'ua',
    'pl': 'pl',
    'poland': 'pl',
    'polska': 'pl',
    'польша': 'pl',
    'polen': 'pl',
    'us': 'us',
    'usa': 'us',
    'unitedstates': 'us',
    'states': 'us',
    'америка': 'us',
    'сша': 'us',
    'gb': 'gb',
    'uk': 'gb',
    'unitedkingdom': 'gb',
    'britain': 'gb',
    'england': 'gb',
    'великабритания': 'gb',
    'de': 'de',
    'germany': 'de',
    'deutschland': 'de',
    'германия': 'de',
    'fr': 'fr',
    'france': 'fr',
    'франция': 'fr',
    'es': 'es',
    'spain': 'es',
    'espana': 'es',
    'испания': 'es',
    'it': 'it',
    'italy': 'it',
    'italia': 'it',
    'италия': 'it',
    'se': 'se',
    'sweden': 'se',
    'sverige': 'se',
    'швеция': 'se',
    'ca': 'ca',
    'canada': 'ca',
    'канада': 'ca',
    'br': 'br',
    'brazil': 'br',
    'brasil': 'br',
    'бразилия': 'br',
    'kr': 'kr',
    'korea': 'kr',
    'southkorea': 'kr',
    'koreasouth': 'kr',
    'корея': 'kr',
    'южнаякорея': 'kr',
    'cn': 'cn',
    'china': 'cn',
    'китай': 'cn',
    'jp': 'jp',
    'japan': 'jp',
    'япония': 'jp',
    'ru': 'ru',
    'russia': 'ru',
    'россия': 'ru',
}


def _get_db_settings() -> dict[str, str]:
    settings = {
        'user': os.getenv('user', '').strip(),
        'password': os.getenv('password', '').strip(),
        'host': os.getenv('host', '').strip(),
        'port': os.getenv('port', '').strip(),
        'dbname': os.getenv('dbname', '').strip(),
        'sslmode': os.getenv('sslmode', 'require').strip() or 'require',
    }

    missing = [key for key in REQUIRED_ENV_VARS if not settings[key]]
    if missing:
        joined = ', '.join(missing)
        raise DatabaseConfigError(f'Missing database environment variables: {joined}')

    return settings


_DB_POOL: ThreadedConnectionPool | None = None
_DB_POOL_LOCK = threading.Lock()

_CACHE_LOCK = threading.Lock()
_CACHE_STORE: dict[tuple, tuple[float, object]] = {}
_CACHE_TTL_SHORT = 10.0
_CACHE_TTL_PROFILE = 5.0

_PLAYER_COLUMN_NAMES_CACHE: set[str] | None = None
_PLAYER_COLUMN_NAMES_LOCK = threading.Lock()


def _get_pool_size_settings() -> tuple[int, int]:
    try:
        minconn = int(os.getenv('DB_POOL_MIN', '1').strip() or '1')
    except ValueError:
        minconn = 1

    try:
        maxconn = int(os.getenv('DB_POOL_MAX', '10').strip() or '10')
    except ValueError:
        maxconn = 10

    minconn = max(1, minconn)
    maxconn = max(minconn, maxconn)
    return minconn, maxconn


def _close_db_pool() -> None:
    global _DB_POOL

    with _DB_POOL_LOCK:
        if _DB_POOL is not None:
            _DB_POOL.closeall()
            _DB_POOL = None


def _get_db_pool() -> ThreadedConnectionPool:
    global _DB_POOL

    if _DB_POOL is not None:
        return _DB_POOL

    with _DB_POOL_LOCK:
        if _DB_POOL is None:
            settings = _get_db_settings()
            minconn, maxconn = _get_pool_size_settings()
            _DB_POOL = ThreadedConnectionPool(
                minconn=minconn,
                maxconn=maxconn,
                user=settings['user'],
                password=settings['password'],
                host=settings['host'],
                port=settings['port'],
                dbname=settings['dbname'],
                sslmode=settings['sslmode'],
                cursor_factory=RealDictCursor,
            )
            atexit.register(_close_db_pool)

    return _DB_POOL


def _make_cache_key(prefix: str, *parts) -> tuple:
    return (prefix, *parts)


def _cache_get(key: tuple):
    now = time.monotonic()

    with _CACHE_LOCK:
        cached = _CACHE_STORE.get(key)
        if not cached:
            return None

        expires_at, value = cached
        if expires_at <= now:
            _CACHE_STORE.pop(key, None)
            return None

        return copy.deepcopy(value)


def _cache_set(key: tuple, value, ttl_seconds: float) -> None:
    expires_at = time.monotonic() + max(0.0, ttl_seconds)

    with _CACHE_LOCK:
        _CACHE_STORE[key] = (expires_at, copy.deepcopy(value))


def invalidate_query_caches() -> None:
    with _CACHE_LOCK:
        _CACHE_STORE.clear()


@contextmanager
def get_db_connection() -> Generator[psycopg2.extensions.connection, None, None]:
    pool = _get_db_pool()
    connection = pool.getconn()
    try:
        yield connection
    finally:
        try:
            connection.rollback()
        except Exception:
            pass
        pool.putconn(connection)


def ensure_database_schema() -> None:
    return None


def ping_database() -> tuple[bool, str | None]:
    try:
        with get_db_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute('SELECT 1 AS ok;')
                cursor.fetchone()
        return True, None
    except Exception as exc:
        return False, str(exc)


def _normalize_text(value: str | None) -> str:
    if value is None:
        return ''
    return str(value).strip()


def _normalize_race_label(value: str | None) -> str:
    clean_value = _normalize_text(value)
    if not clean_value:
        return ''
    return RACE_LABELS.get(clean_value, clean_value)


def _normalize_elo_value(value) -> str:
    if value is None:
        return '—'

    try:
        return str(int(value))
    except (TypeError, ValueError):
        return str(value)


def _normalize_discord_url(value: str | None) -> str:
    clean_value = _normalize_text(value)
    if not clean_value:
        return ''

    if re.match(r'^[a-z][a-z0-9+.-]*://', clean_value, re.IGNORECASE):
        return clean_value

    return f'https://{clean_value}'


def _slugify(value: str | None) -> str:
    clean_value = _normalize_text(value).lower()
    if not clean_value:
        return ''
    return re.sub(r'[^a-zа-яё0-9]+', '', clean_value)


def _build_flag_index() -> dict[str, str]:
    if not FLAGS_DIR.exists():
        return {}

    index: dict[str, str] = {}
    for path in FLAGS_DIR.rglob('*'):
        if not path.is_file() or path.suffix.lower() not in ALLOWED_FLAG_EXTENSIONS:
            continue

        relative_path = path.relative_to(FLAGS_DIR).as_posix()
        web_path = f'/static/Flags/{relative_path}'

        candidates = {
            _slugify(path.stem),
            _slugify(relative_path),
            _slugify(path.name),
        }

        for candidate in list(candidates):
            alias = COUNTRY_ALIASES.get(candidate)
            if alias:
                candidates.add(alias)

        for candidate in candidates:
            if candidate and candidate not in index:
                index[candidate] = web_path

    return index


FLAG_INDEX = _build_flag_index()


def _resolve_flag_url(country_code: str | None, country_name: str | None) -> str:
    candidates = []

    code_key = COUNTRY_ALIASES.get(_slugify(country_code), _slugify(country_code))
    name_key = COUNTRY_ALIASES.get(_slugify(country_name), _slugify(country_name))

    if code_key:
        candidates.append(code_key)
    if name_key and name_key not in candidates:
        candidates.append(name_key)

    for candidate in candidates:
        flag_url = FLAG_INDEX.get(candidate)
        if flag_url:
            return flag_url

    return ''


def _get_player_column_names(connection: psycopg2.extensions.connection) -> set[str]:
    global _PLAYER_COLUMN_NAMES_CACHE

    if _PLAYER_COLUMN_NAMES_CACHE is not None:
        return set(_PLAYER_COLUMN_NAMES_CACHE)

    with _PLAYER_COLUMN_NAMES_LOCK:
        if _PLAYER_COLUMN_NAMES_CACHE is None:
            with connection.cursor() as cursor:
                cursor.execute(
                    '''
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = 'public'
                      AND table_name = 'players';
                    '''
                )
                rows = cursor.fetchall()
            _PLAYER_COLUMN_NAMES_CACHE = {row['column_name'] for row in rows}

    return set(_PLAYER_COLUMN_NAMES_CACHE or set())


def _humanize_last_played(value) -> str:
    if not value:
        return '—'

    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return value
    else:
        parsed = value

    now = datetime.now(parsed.tzinfo) if getattr(parsed, 'tzinfo', None) else datetime.now()
    delta = now - parsed
    total_seconds = int(delta.total_seconds())

    if total_seconds < 0:
        return parsed.strftime('%Y-%m-%d')
    if total_seconds < 3600:
        minutes = max(1, total_seconds // 60)
        return f'{minutes} min'
    if total_seconds < 86400:
        hours = total_seconds // 3600
        return '1 hour' if hours == 1 else f'{hours} hours'
    if total_seconds < 2592000:
        days = total_seconds // 86400
        return '1 day' if days == 1 else f'{days} days'

    return parsed.strftime('%Y-%m-%d')


def _format_match_datetime(value) -> str:
    if not value:
        return '—'

    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return value
    else:
        parsed = value

    return parsed.strftime('%Y-%m-%d %H:%M')


def _format_match_date(value) -> str:
    if not value:
        return '—'

    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return value
    else:
        parsed = value

    return parsed.strftime('%Y-%m-%d')


def _format_percent(value) -> str:
    if value is None:
        return '0%'

    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)

    if numeric.is_integer():
        return f'{int(numeric)}%'
    return f'{numeric:.1f}%'


def _format_delta(value) -> str:
    if value is None:
        return '—'

    try:
        numeric = int(value)
    except (TypeError, ValueError):
        return str(value)

    if numeric > 0:
        return f'+{numeric}'
    return str(numeric)


def _get_player_select_expressions(connection: psycopg2.extensions.connection) -> dict[str, str]:
    player_columns = _get_player_column_names(connection)

    if 'country_code' in player_columns:
        country_code_expr = "NULLIF(TRIM(p.country_code), '')"
    elif 'country' in player_columns:
        country_code_expr = 'NULL::text'
    else:
        country_code_expr = 'NULL::text'

    if 'country_name' in player_columns:
        country_name_expr = "NULLIF(TRIM(p.country_name), '')"
    elif 'country' in player_columns:
        country_name_expr = "NULLIF(TRIM(p.country), '')"
    else:
        country_name_expr = 'NULL::text'

    if 'priority_race' in player_columns:
        priority_race_expr = "NULLIF(TRIM(p.priority_race), '')"
    else:
        priority_race_expr = 'NULL::text'

    if 'discord_url' in player_columns:
        discord_url_expr = "NULLIF(TRIM(p.discord_url), '')"
    else:
        discord_url_expr = 'NULL::text'

    return {
        'country_code_expr': country_code_expr,
        'country_name_expr': country_name_expr,
        'priority_race_expr': priority_race_expr,
        'discord_url_expr': discord_url_expr,
    }


def _prepare_player_row(row: dict) -> dict:
    player = dict(row)
    player['country_name'] = _normalize_text(player.get('country_name'))
    player['country_code'] = _normalize_text(player.get('country_code'))
    player['priority_race'] = _normalize_race_label(player.get('priority_race'))
    player['discord_url'] = _normalize_discord_url(player.get('discord_url'))
    player['flag_url'] = _resolve_flag_url(player.get('country_code'), player.get('country_name'))
    player['last_played_label'] = _humanize_last_played(player.get('last_match_at'))
    player['current_elo_display'] = _normalize_elo_value(player.get('current_elo'))
    player['win_rate_display'] = _format_percent(player.get('win_rate'))
    player['profile_url'] = f"/players/{player['id']}"
    return player


def _build_rating_chart(current_elo, rating_rows: list[dict]) -> dict:
    series: list[dict] = []

    if rating_rows:
        first_old_elo = rating_rows[0].get('old_elo')
        first_played_at = rating_rows[0].get('played_at')
        if first_old_elo is not None:
            try:
                series.append(
                    {
                        'label': 'Start',
                        'full_label': 'Starting rating',
                        'elo': int(first_old_elo),
                        'played_at': first_played_at,
                        'played_at_label': _format_match_datetime(first_played_at),
                    }
                )
            except (TypeError, ValueError):
                pass

        for row in rating_rows:
            try:
                old_elo_value = int(row.get('old_elo')) if row.get('old_elo') is not None else None
                elo_value = int(row.get('new_elo'))
                elo_delta_value = int(row.get('elo_delta')) if row.get('elo_delta') is not None else None
            except (TypeError, ValueError):
                continue

            played_at_value = row.get('played_at')
            series.append(
                {
                    'label': _format_match_date(played_at_value),
                    'full_label': _format_match_datetime(played_at_value),
                    'played_at': played_at_value,
                    'played_at_label': _format_match_datetime(played_at_value),
                    'elo': elo_value,
                    'old_elo': old_elo_value,
                    'elo_delta': elo_delta_value,
                }
            )

    if not series:
        fallback_elo = 1000
        try:
            fallback_elo = int(current_elo)
        except (TypeError, ValueError):
            pass

        series = [
            {
                'label': 'Current',
                'full_label': 'Current rating',
                'played_at': None,
                'played_at_label': 'Current rating',
                'elo': fallback_elo,
                'old_elo': fallback_elo,
                'elo_delta': 0,
            }
        ]

    raw_values = [point['elo'] for point in series]
    raw_low_value = min(raw_values)
    raw_high_value = max(raw_values)

    if len(series) <= 2:
        ema_values = raw_values[:]
    else:
        smoothing_span = max(8, min(22, math.ceil(len(series) / 24)))
        alpha = 2 / (smoothing_span + 1)
        ema_values = []
        previous_ema = float(raw_values[0])
        for value in raw_values:
            previous_ema = (alpha * float(value)) + ((1 - alpha) * previous_ema)
            ema_values.append(round(previous_ema, 2))

    combined_values = raw_values + ema_values
    low_value = min(combined_values)
    high_value = max(combined_values)
    spread = high_value - low_value
    padding = max(16, math.ceil(spread * 0.12)) if spread else 24
    axis_min = max(0, math.floor(low_value - padding))
    axis_max = math.ceil(high_value + padding)

    if axis_max <= axis_min:
        axis_max = axis_min + 1

    width = 980
    height = 328
    plot_left = 58
    plot_right = 18
    plot_top = 18
    plot_bottom = 58
    plot_width = width - plot_left - plot_right
    plot_height = height - plot_top - plot_bottom

    def point_x(index: int) -> float:
        if len(series) == 1:
            return plot_left + plot_width / 2
        return plot_left + (plot_width * index) / (len(series) - 1)

    def point_y(value: float) -> float:
        return plot_top + ((axis_max - value) / (axis_max - axis_min)) * plot_height

    raw_pairs = []
    ema_pairs = []
    hover_points = []

    for index, point in enumerate(series):
        x_value = point_x(index)
        raw_y = point_y(point['elo'])
        ema_y = point_y(ema_values[index])

        raw_pairs.append(f'{x_value:.2f},{raw_y:.2f}')
        ema_pairs.append(f'{x_value:.2f},{ema_y:.2f}')

        hover_points.append(
            {
                'x': round(x_value, 2),
                'raw_y': round(raw_y, 2),
                'ema_y': round(ema_y, 2),
                'elo': point['elo'],
                'smoothed_elo': round(ema_values[index], 2),
                'label': point.get('full_label') or point['label'],
                'played_at_label': point.get('played_at_label') or point.get('full_label') or point['label'],
                'date_label': _format_match_date(point.get('played_at')) if point.get('played_at') else point.get('label') or '',
                'elo_delta_display': _format_delta(point.get('elo_delta')),
                'old_elo_display': _normalize_elo_value(point.get('old_elo')),
                'new_elo_display': _normalize_elo_value(point.get('elo')),
            }
        )

    def build_area(points: list[str], first_x: float, last_x: float) -> str:
        return f"{first_x:.2f},{plot_top + plot_height:.2f} {' '.join(points)} {last_x:.2f},{plot_top + plot_height:.2f}"

    if hover_points:
        raw_area_points = build_area(raw_pairs, hover_points[0]['x'], hover_points[-1]['x'])
        ema_area_points = build_area(ema_pairs, hover_points[0]['x'], hover_points[-1]['x'])

        for index, point in enumerate(hover_points):
            if len(hover_points) == 1:
                left_x = plot_left
                right_x = plot_left + plot_width
            else:
                prev_x = hover_points[index - 1]['x'] if index > 0 else point['x']
                next_x = hover_points[index + 1]['x'] if index < len(hover_points) - 1 else point['x']
                left_x = plot_left if index == 0 else (prev_x + point['x']) / 2
                right_x = plot_left + plot_width if index == len(hover_points) - 1 else (point['x'] + next_x) / 2

            point['band_x'] = round(left_x, 2)
            point['band_width'] = round(max(8, right_x - left_x), 2)
    else:
        raw_area_points = ''
        ema_area_points = ''

    tick_count = 5
    y_ticks = []
    for index in range(tick_count):
        ratio = index / (tick_count - 1)
        y_value = plot_top + ratio * plot_height
        elo_value = axis_max - ratio * (axis_max - axis_min)
        y_ticks.append({'y': round(y_value, 2), 'label': str(int(round(elo_value)))})

    x_ticks = []
    if hover_points:
        max_x_ticks = min(7, len(hover_points))
        tick_indices = sorted(
            {
                round(step * (len(hover_points) - 1) / max(1, max_x_ticks - 1))
                for step in range(max_x_ticks)
            }
        )
        for index in tick_indices:
            point = hover_points[index]
            x_ticks.append(
                {
                    'x': point['x'],
                    'label': point.get('date_label') or point.get('played_at_label') or '—',
                }
            )

    start_label = series[0].get('full_label') or series[0]['label']
    end_label = series[-1].get('full_label') or series[-1]['label']

    return {
        'width': width,
        'height': height,
        'plot_left': plot_left,
        'plot_right': plot_right,
        'plot_top': plot_top,
        'plot_bottom': plot_bottom,
        'plot_width': plot_width,
        'plot_height': plot_height,
        'raw_points_attr': ' '.join(raw_pairs),
        'raw_area_points': raw_area_points,
        'smoothed_points_attr': ' '.join(ema_pairs),
        'smoothed_area_points': ema_area_points,
        'hover_points': hover_points,
        'y_ticks': y_ticks,
        'x_ticks': x_ticks,
        'lowest_elo': raw_low_value,
        'highest_elo': raw_high_value,
        'current_elo': raw_values[-1],
        'matches_tracked': max(0, len(series) - 1),
        'start_label': start_label,
        'end_label': end_label,
        'smoothing_label': 'EMA',
    }


def fetch_leaderboard(search: str = '', limit: int = 100) -> list[dict]:
    safe_limit = max(1, min(limit, 500))
    normalized_search = search.strip()
    like_pattern = f'%{normalized_search}%'
    cache_key = _make_cache_key('leaderboard', normalized_search.casefold(), safe_limit)
    cached_rows = _cache_get(cache_key)
    if cached_rows is not None:
        return cached_rows

    with get_db_connection() as connection:
        expr = _get_player_select_expressions(connection)

        query = f'''
        WITH ranked AS (
            SELECT
                p.id,
                p.name,
                p.current_elo AS current_elo,
                p.last_match_at,
                {expr['country_code_expr']} AS country_code,
                {expr['country_name_expr']} AS country_name,
                {expr['priority_race_expr']} AS priority_race,
                p.matches_count,
                p.wins,
                p.losses,
                ROW_NUMBER() OVER (
                    ORDER BY p.current_elo DESC, p.wins DESC, p.matches_count DESC, p.name ASC
                ) AS rank_position,
                CASE
                    WHEN p.matches_count > 0 THEN ROUND((p.wins::numeric / p.matches_count::numeric) * 100, 1)
                    ELSE 0
                END AS win_rate
            FROM players p
            WHERE p.is_active = TRUE
              AND (%s = '' OR p.name ILIKE %s)
        )
        SELECT
            id,
            name,
            current_elo,
            last_match_at,
            country_code,
            country_name,
            priority_race,
            matches_count,
            wins,
            losses,
            rank_position,
            win_rate
        FROM ranked
        ORDER BY rank_position ASC
        LIMIT %s;
        '''

        with connection.cursor() as cursor:
            cursor.execute(query, (normalized_search, like_pattern, safe_limit))
            rows = cursor.fetchall()

    prepared_rows = [_prepare_player_row(row) for row in rows]
    _cache_set(cache_key, prepared_rows, _CACHE_TTL_SHORT)
    return prepared_rows



def _prepare_game_report_row(row: dict) -> dict:
    match = dict(row)
    match['played_at_label'] = _format_match_date(match.get('played_at'))
    match['winner_race'] = _normalize_race_label(match.get('winner_race'))
    match['loser_race'] = _normalize_race_label(match.get('loser_race'))
    match['winner_profile_url'] = f"/players/{match['winner_id']}"
    match['loser_profile_url'] = f"/players/{match['loser_id']}"
    match['winner_elo_delta_display'] = _format_delta(match.get('winner_elo_delta'))
    match['loser_elo_delta_display'] = _format_delta(match.get('loser_elo_delta'))
    match['winner_rating_display'] = f"{_normalize_elo_value(match.get('winner_old_elo'))} → {_normalize_elo_value(match.get('winner_new_elo'))}" if match.get('winner_old_elo') is not None and match.get('winner_new_elo') is not None else '—'
    match['loser_rating_display'] = f"{_normalize_elo_value(match.get('loser_old_elo'))} → {_normalize_elo_value(match.get('loser_new_elo'))}" if match.get('loser_old_elo') is not None and match.get('loser_new_elo') is not None else '—'
    match['ranked_label'] = 'Ranked' if match.get('is_ranked') else 'Unranked'
    match['comment_display'] = _normalize_text(match.get('comment')) or '—'
    match['game_type_display'] = _normalize_text(match.get('game_type')) or '—'
    match['mission_name_display'] = _normalize_text(match.get('mission_name')) or '—'
    return match



def fetch_game_reports(search: str = '', limit: int = 100) -> list[dict]:
    safe_limit = max(1, min(limit, 500))
    normalized_search = search.strip()
    like_pattern = f'%{normalized_search}%'
    cache_key = _make_cache_key('reports', normalized_search.casefold(), safe_limit)
    cached_rows = _cache_get(cache_key)
    if cached_rows is not None:
        return cached_rows

    query = '''
    SELECT
        m.id,
        m.played_at,
        winner.id AS winner_id,
        winner.name AS winner_name,
        loser.id AS loser_id,
        loser.name AS loser_name,
        CASE
            WHEN m.winner_player_id = m.player1_id THEN m.player1_race
            ELSE m.player2_race
        END AS winner_race,
        CASE
            WHEN m.winner_player_id = m.player1_id THEN m.player2_race
            ELSE m.player1_race
        END AS loser_race,
        m.is_ranked,
        m.game_type,
        m.mission_name,
        m.comment,
        winner_history.old_elo AS winner_old_elo,
        winner_history.new_elo AS winner_new_elo,
        winner_history.elo_delta AS winner_elo_delta,
        loser_history.old_elo AS loser_old_elo,
        loser_history.new_elo AS loser_new_elo,
        loser_history.elo_delta AS loser_elo_delta
    FROM matches m
    JOIN players winner ON winner.id = m.winner_player_id
    JOIN players loser
      ON loser.id = CASE
            WHEN m.winner_player_id = m.player1_id THEN m.player2_id
            ELSE m.player1_id
        END
    LEFT JOIN rating_history winner_history
      ON winner_history.match_id = m.id
     AND winner_history.player_id = winner.id
    LEFT JOIN rating_history loser_history
      ON loser_history.match_id = m.id
     AND loser_history.player_id = loser.id
    WHERE (
            %s = ''
            OR winner.name ILIKE %s
            OR loser.name ILIKE %s
            OR COALESCE(m.game_type, '') ILIKE %s
            OR COALESCE(m.mission_name, '') ILIKE %s
            OR COALESCE(m.comment, '') ILIKE %s
          )
    ORDER BY m.played_at DESC, m.id DESC
    LIMIT %s;
    '''

    with get_db_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                query,
                (
                    normalized_search,
                    like_pattern,
                    like_pattern,
                    like_pattern,
                    like_pattern,
                    like_pattern,
                    safe_limit,
                ),
            )
            rows = cursor.fetchall()

    prepared_rows = [_prepare_game_report_row(row) for row in rows]
    _cache_set(cache_key, prepared_rows, _CACHE_TTL_SHORT)
    return prepared_rows


def fetch_player_profile(player_id: int, recent_matches_limit: int = 20) -> dict | None:
    safe_recent_matches_limit = max(1, min(recent_matches_limit, 50))
    cache_key = _make_cache_key('player_profile', int(player_id), safe_recent_matches_limit)
    cached_profile = _cache_get(cache_key)
    if cached_profile is not None:
        return cached_profile

    with get_db_connection() as connection:
        expr = _get_player_select_expressions(connection)

        profile_query = f'''
        WITH ranked AS (
            SELECT
                p.id,
                p.name,
                p.current_elo,
                p.last_match_at,
                {expr['country_code_expr']} AS country_code,
                {expr['country_name_expr']} AS country_name,
                {expr['priority_race_expr']} AS priority_race,
                {expr['discord_url_expr']} AS discord_url,
                p.matches_count,
                p.wins,
                p.losses,
                p.created_at,
                ROW_NUMBER() OVER (
                    ORDER BY p.current_elo DESC, p.wins DESC, p.matches_count DESC, p.name ASC
                ) AS rank_position,
                CASE
                    WHEN p.matches_count > 0 THEN ROUND((p.wins::numeric / p.matches_count::numeric) * 100, 1)
                    ELSE 0
                END AS win_rate
            FROM players p
            WHERE p.is_active = TRUE
        )
        SELECT
            id,
            name,
            current_elo,
            last_match_at,
            country_code,
            country_name,
            priority_race,
            discord_url,
            matches_count,
            wins,
            losses,
            created_at,
            rank_position,
            win_rate
        FROM ranked
        WHERE id = %s;
        '''

        recent_matches_query = '''
        SELECT
            m.id,
            m.played_at,
            CASE
                WHEN m.player1_id = %(player_id)s THEN opponent_two.id
                ELSE opponent_one.id
            END AS opponent_id,
            CASE
                WHEN m.player1_id = %(player_id)s THEN opponent_two.name
                ELSE opponent_one.name
            END AS opponent_name,
            CASE
                WHEN m.winner_player_id = %(player_id)s THEN 'Win'
                ELSE 'Loss'
            END AS result_label,
            CASE
                WHEN m.winner_player_id = %(player_id)s THEN TRUE
                ELSE FALSE
            END AS is_win,
            CASE
                WHEN m.player1_id = %(player_id)s THEN m.player1_race
                ELSE m.player2_race
            END AS player_race,
            CASE
                WHEN m.player1_id = %(player_id)s THEN m.player2_race
                ELSE m.player1_race
            END AS opponent_race,
            rh.old_elo,
            rh.new_elo,
            rh.elo_delta
        FROM matches m
        JOIN players opponent_one ON opponent_one.id = m.player1_id
        JOIN players opponent_two ON opponent_two.id = m.player2_id
        LEFT JOIN rating_history rh
            ON rh.match_id = m.id
           AND rh.player_id = %(player_id)s
        WHERE m.player1_id = %(player_id)s OR m.player2_id = %(player_id)s
        ORDER BY m.played_at DESC, m.id DESC
        LIMIT %(recent_limit)s;
        '''

        rating_chart_query = '''
        SELECT
            m.played_at,
            rh.old_elo,
            rh.new_elo,
            rh.elo_delta
        FROM rating_history rh
        JOIN matches m ON m.id = rh.match_id
        WHERE rh.player_id = %s
        ORDER BY m.played_at ASC, rh.id ASC;
        '''

        with connection.cursor() as cursor:
            cursor.execute(profile_query, (player_id,))
            player_row = cursor.fetchone()

            if not player_row:
                return None

            cursor.execute(
                recent_matches_query,
                {
                    'player_id': player_id,
                    'recent_limit': safe_recent_matches_limit,
                },
            )
            match_rows = cursor.fetchall()

            cursor.execute(rating_chart_query, (player_id,))
            rating_rows = cursor.fetchall()

    player = _prepare_player_row(player_row)
    player['member_since_label'] = _format_match_datetime(player.get('created_at'))

    recent_matches: list[dict] = []
    for row in match_rows:
        match = dict(row)
        match['played_at_label'] = _format_match_date(match.get('played_at'))
        match['player_race'] = _normalize_race_label(match.get('player_race'))
        match['opponent_race'] = _normalize_race_label(match.get('opponent_race'))
        match['old_elo_display'] = _normalize_elo_value(match.get('old_elo'))
        match['new_elo_display'] = _normalize_elo_value(match.get('new_elo'))
        match['elo_delta_display'] = _format_delta(match.get('elo_delta'))
        match['opponent_profile_url'] = f"/players/{match['opponent_id']}"
        recent_matches.append(match)

    rating_chart = _build_rating_chart(player.get('current_elo'), [dict(row) for row in rating_rows])

    profile = {
        'player': player,
        'recent_matches': recent_matches,
        'rating_chart': rating_chart,
    }
    _cache_set(cache_key, profile, _CACHE_TTL_PROFILE)
    return profile


RACE_OPTIONS = ('Терран', 'Протосс', 'Зерг')
GAME_TYPE_OPTIONS = ('1к', '2к', 'Grand Offensive')
DEFAULT_K_FACTOR = 32


def _normalize_player_name(value: str | None) -> str:
    clean_value = _normalize_text(value)
    if not clean_value:
        return ''
    return re.sub(r'\s+', ' ', clean_value).strip()


def _normalize_player_key(value: str | None) -> str:
    clean_value = _normalize_player_name(value)
    if not clean_value:
        return ''
    return clean_value.casefold()


def _coerce_ranked_value(value) -> bool:
    if isinstance(value, bool):
        return value
    normalized = _normalize_text(value).lower()
    return normalized in {'1', 'true', 'yes', 'y', 'ranked', 'on'}


def _calculate_expected_score(player_elo: int, opponent_elo: int) -> float:
    return 1 / (1 + 10 ** ((opponent_elo - player_elo) / 400))


def _calculate_elo_result(winner_elo: int, loser_elo: int, k_factor: int = DEFAULT_K_FACTOR) -> dict:
    expected_winner = _calculate_expected_score(winner_elo, loser_elo)
    expected_loser = _calculate_expected_score(loser_elo, winner_elo)

    winner_delta = int(round(k_factor * (1 - expected_winner)))
    loser_delta = -winner_delta

    winner_new = max(0, winner_elo + winner_delta)
    loser_new = max(0, loser_elo + loser_delta)

    return {
        'winner_old_elo': winner_elo,
        'winner_new_elo': winner_new,
        'winner_delta': winner_delta,
        'winner_expected_score': expected_winner,
        'loser_old_elo': loser_elo,
        'loser_new_elo': loser_new,
        'loser_delta': loser_delta,
        'loser_expected_score': expected_loser,
        'k_factor': k_factor,
    }


def _get_or_create_player(cursor, player_name: str) -> dict:
    normalized_name = _normalize_player_name(player_name)
    normalized_key = _normalize_player_key(player_name)

    cursor.execute(
        '''
        SELECT id, name, current_elo, is_active
        FROM players
        WHERE name_normalized = %s
        LIMIT 1;
        ''',
        (normalized_key,),
    )
    row = cursor.fetchone()

    if row:
        player = dict(row)
        if player['name'] != normalized_name or not player.get('is_active', True):
            cursor.execute(
                '''
                UPDATE players
                SET name = %s,
                    is_active = TRUE,
                    updated_at = NOW()
                WHERE id = %s
                RETURNING id, name, current_elo, is_active;
                ''',
                (normalized_name, player['id']),
            )
            player = dict(cursor.fetchone())
        player['created'] = False
        return player

    cursor.execute(
        '''
        INSERT INTO players (
            name,
            name_normalized,
            current_elo,
            matches_count,
            wins,
            losses,
            is_active,
            created_at,
            updated_at
        )
        VALUES (%s, %s, 1000, 0, 0, 0, TRUE, NOW(), NOW())
        RETURNING id, name, current_elo, is_active;
        ''',
        (normalized_name, normalized_key),
    )
    player = dict(cursor.fetchone())
    player['created'] = True
    return player


def _refresh_priority_race(cursor, player_id: int) -> None:
    cursor.execute(
        '''
        WITH race_counts AS (
            SELECT race, COUNT(*)::int AS race_count
            FROM (
                SELECT m.player1_race AS race
                FROM matches m
                WHERE m.player1_id = %s
                  AND m.player1_race IS NOT NULL

                UNION ALL

                SELECT m.player2_race AS race
                FROM matches m
                WHERE m.player2_id = %s
                  AND m.player2_race IS NOT NULL
            ) races
            GROUP BY race
            ORDER BY race_count DESC, race ASC
            LIMIT 1
        )
        UPDATE players p
        SET priority_race = (SELECT race FROM race_counts),
            updated_at = NOW()
        WHERE p.id = %s;
        ''',
        (player_id, player_id, player_id),
    )


def fetch_player_name_suggestions(limit: int = 500) -> list[str]:
    safe_limit = max(1, min(limit, 2000))
    cache_key = _make_cache_key('player_name_suggestions', safe_limit)
    cached_rows = _cache_get(cache_key)
    if cached_rows is not None:
        return cached_rows

    with get_db_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                '''
                SELECT name
                FROM players
                WHERE is_active = TRUE
                ORDER BY current_elo DESC, name ASC
                LIMIT %s;
                ''',
                (safe_limit,),
            )
            rows = cursor.fetchall()

    names = [row['name'] for row in rows if _normalize_text(row.get('name'))]
    _cache_set(cache_key, names, 60.0)
    return names


def fetch_mission_suggestions(limit: int = 50) -> list[str]:
    safe_limit = max(1, min(limit, 200))
    cache_key = _make_cache_key('mission_suggestions', safe_limit)
    cached_rows = _cache_get(cache_key)
    if cached_rows is not None:
        return cached_rows

    with get_db_connection() as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                '''
                SELECT DISTINCT mission_name
                FROM matches
                WHERE mission_name IS NOT NULL
                  AND NULLIF(TRIM(mission_name), '') IS NOT NULL
                ORDER BY mission_name ASC
                LIMIT %s;
                ''',
                (safe_limit,),
            )
            rows = cursor.fetchall()

    mission_names = [row['mission_name'] for row in rows if _normalize_text(row.get('mission_name'))]
    _cache_set(cache_key, mission_names, 60.0)
    return mission_names


def submit_match_result(
    *,
    winner_name: str,
    opponent_name: str,
    winner_race: str,
    opponent_race: str,
    is_ranked,
    game_type: str,
    mission_name: str,
    comment: str = '',
) -> dict:
    clean_winner_name = _normalize_player_name(winner_name)
    clean_opponent_name = _normalize_player_name(opponent_name)
    clean_winner_race = _normalize_text(winner_race)
    clean_opponent_race = _normalize_text(opponent_race)
    clean_game_type = _normalize_text(game_type)
    clean_mission_name = _normalize_player_name(mission_name)
    clean_comment = _normalize_text(comment)
    ranked_match = _coerce_ranked_value(is_ranked)

    if not clean_winner_name:
        raise ValueError('Enter the winner name.')
    if not clean_opponent_name:
        raise ValueError('Enter the opponent name.')
    if _normalize_player_key(clean_winner_name) == _normalize_player_key(clean_opponent_name):
        raise ValueError('Winner and opponent must be different players.')
    if clean_winner_race not in RACE_OPTIONS:
        raise ValueError('Choose the winner race.')
    if clean_opponent_race not in RACE_OPTIONS:
        raise ValueError('Choose the opponent race.')
    if clean_game_type not in GAME_TYPE_OPTIONS:
        raise ValueError('Choose the game type.')
    if not clean_mission_name:
        raise ValueError('Choose the mission.')
    if len(clean_comment) > 4000:
        raise ValueError('Comment is too long.')

    played_at = datetime.now()

    with get_db_connection() as connection:
        try:
            with connection.cursor() as cursor:
                winner_player = _get_or_create_player(cursor, clean_winner_name)
                opponent_player = _get_or_create_player(cursor, clean_opponent_name)

                cursor.execute(
                    '''
                    INSERT INTO matches (
                        player1_id,
                        player2_id,
                        winner_player_id,
                        played_at,
                        created_at,
                        comment,
                        player1_race,
                        player2_race,
                        is_ranked,
                        game_type,
                        mission_name
                    )
                    VALUES (%s, %s, %s, %s, NOW(), %s, %s, %s, %s, %s, %s)
                    RETURNING id, played_at;
                    ''',
                    (
                        winner_player['id'],
                        opponent_player['id'],
                        winner_player['id'],
                        played_at,
                        clean_comment or None,
                        clean_winner_race,
                        clean_opponent_race,
                        ranked_match,
                        clean_game_type,
                        clean_mission_name,
                    ),
                )
                match_row = dict(cursor.fetchone())

                winner_old_elo = int(winner_player.get('current_elo') or 1000)
                opponent_old_elo = int(opponent_player.get('current_elo') or 1000)

                if ranked_match:
                    elo_result = _calculate_elo_result(winner_old_elo, opponent_old_elo)
                    winner_new_elo = elo_result['winner_new_elo']
                    opponent_new_elo = elo_result['loser_new_elo']
                else:
                    elo_result = {
                        'winner_old_elo': winner_old_elo,
                        'winner_new_elo': winner_old_elo,
                        'winner_delta': 0,
                        'winner_expected_score': 0,
                        'loser_old_elo': opponent_old_elo,
                        'loser_new_elo': opponent_old_elo,
                        'loser_delta': 0,
                        'loser_expected_score': 0,
                        'k_factor': 0,
                    }
                    winner_new_elo = winner_old_elo
                    opponent_new_elo = opponent_old_elo

                cursor.execute(
                    '''
                    UPDATE players
                    SET current_elo = %s,
                        matches_count = matches_count + 1,
                        wins = wins + 1,
                        last_match_at = %s,
                        updated_at = NOW()
                    WHERE id = %s;
                    ''',
                    (winner_new_elo, played_at, winner_player['id']),
                )
                cursor.execute(
                    '''
                    UPDATE players
                    SET current_elo = %s,
                        matches_count = matches_count + 1,
                        losses = losses + 1,
                        last_match_at = %s,
                        updated_at = NOW()
                    WHERE id = %s;
                    ''',
                    (opponent_new_elo, played_at, opponent_player['id']),
                )

                if ranked_match:
                    cursor.execute(
                        '''
                        INSERT INTO rating_history (
                            match_id,
                            player_id,
                            old_elo,
                            new_elo,
                            elo_delta,
                            expected_score,
                            actual_score,
                            k_factor,
                            created_at
                        )
                        VALUES
                            (%s, %s, %s, %s, %s, %s, 1, %s, NOW()),
                            (%s, %s, %s, %s, %s, %s, 0, %s, NOW());
                        ''',
                        (
                            match_row['id'],
                            winner_player['id'],
                            elo_result['winner_old_elo'],
                            elo_result['winner_new_elo'],
                            elo_result['winner_delta'],
                            elo_result['winner_expected_score'],
                            elo_result['k_factor'],
                            match_row['id'],
                            opponent_player['id'],
                            elo_result['loser_old_elo'],
                            elo_result['loser_new_elo'],
                            elo_result['loser_delta'],
                            elo_result['loser_expected_score'],
                            elo_result['k_factor'],
                        ),
                    )

                _refresh_priority_race(cursor, winner_player['id'])
                _refresh_priority_race(cursor, opponent_player['id'])

            connection.commit()
        except Exception:
            connection.rollback()
            raise

    invalidate_query_caches()

    return {
        'match_id': match_row['id'],
        'played_at_label': _format_match_datetime(match_row.get('played_at') or played_at),
        'winner_player_id': winner_player['id'],
        'winner_name': winner_player['name'],
        'winner_created': winner_player.get('created', False),
        'winner_race': _normalize_race_label(clean_winner_race),
        'winner_profile_url': f"/players/{winner_player['id']}",
        'opponent_player_id': opponent_player['id'],
        'opponent_name': opponent_player['name'],
        'opponent_created': opponent_player.get('created', False),
        'opponent_race': _normalize_race_label(clean_opponent_race),
        'opponent_profile_url': f"/players/{opponent_player['id']}",
        'is_ranked': ranked_match,
        'game_type': clean_game_type,
        'mission_name': clean_mission_name,
        'comment': clean_comment,
        'winner_old_elo_display': _normalize_elo_value(elo_result['winner_old_elo']),
        'winner_new_elo_display': _normalize_elo_value(elo_result['winner_new_elo']),
        'winner_delta_display': _format_delta(elo_result['winner_delta']),
        'opponent_old_elo_display': _normalize_elo_value(elo_result['loser_old_elo']),
        'opponent_new_elo_display': _normalize_elo_value(elo_result['loser_new_elo']),
        'opponent_delta_display': _format_delta(elo_result['loser_delta']),
    }
