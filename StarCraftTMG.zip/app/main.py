from pathlib import Path
from urllib.parse import parse_qs

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.database import (
    fetch_game_reports,
    fetch_leaderboard,
    fetch_mission_suggestions,
    fetch_player_name_suggestions,
    fetch_player_profile,
    ping_database,
    submit_match_result,
)

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent

load_dotenv(PROJECT_ROOT / '.env')

app = FastAPI(title='StarCraft ELO', version='0.1.0')

app.mount('/static', StaticFiles(directory=BASE_DIR / 'static'), name='static')
templates = Jinja2Templates(directory=str(BASE_DIR / 'templates'))

RACE_OPTIONS = [
    {'label': 'Терран', 'slug': 'terran'},
    {'label': 'Протосс', 'slug': 'protoss'},
    {'label': 'Зерг', 'slug': 'zerg'},
]

GAME_TYPE_OPTIONS = ['1к', '2к', 'Grand Offensive']
DEFAULT_MISSION_OPTIONS = [
    'Assault',
    'Breakthrough',
    'Control',
    'Escort',
    'Extraction',
    'Frontline',
    'Hold the Line',
    'Other / Custom',
]


def _merge_mission_options() -> list[str]:
    try:
        db_values = fetch_mission_suggestions(limit=100)
    except Exception:
        db_values = []

    merged = []
    for value in DEFAULT_MISSION_OPTIONS + db_values:
        clean_value = str(value).strip()
        if clean_value and clean_value not in merged:
            merged.append(clean_value)
    return merged


def _build_submit_form_state(raw_values: dict | None = None) -> dict:
    source = raw_values or {}
    return {
        'winner_name': str(source.get('winner_name', '')).strip(),
        'opponent_name': str(source.get('opponent_name', '')).strip(),
        'winner_race': str(source.get('winner_race', 'Терран')).strip() or 'Терран',
        'opponent_race': str(source.get('opponent_race', 'Протосс')).strip() or 'Протосс',
        'is_ranked': str(source.get('is_ranked', 'yes')).strip() or 'yes',
        'game_type': str(source.get('game_type', '1к')).strip() or '1к',
        'mission_name': str(source.get('mission_name', '')).strip(),
        'comment': str(source.get('comment', '')).strip(),
    }


def _render_submit_page(
    request: Request,
    *,
    form_state: dict | None = None,
    error_message: str | None = None,
    success_data: dict | None = None,
    status_code: int = 200,
):
    name_suggestions = []
    try:
        name_suggestions = fetch_player_name_suggestions(limit=1000)
    except Exception:
        name_suggestions = []

    return templates.TemplateResponse(
        'submit_match.html',
        {
            'request': request,
            'page_title': 'Submit Match',
            'active_page': 'submit',
            'race_options': RACE_OPTIONS,
            'game_type_options': GAME_TYPE_OPTIONS,
            'mission_options': _merge_mission_options(),
            'name_suggestions': name_suggestions,
            'form_state': _build_submit_form_state(form_state),
            'error_message': error_message,
            'success_data': success_data,
        },
        status_code=status_code,
    )


@app.get('/', response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        'home.html',
        {
            'request': request,
            'page_title': 'StarCraft ELO',
            'active_page': 'home',
        },
    )


@app.get('/health')
async def health():
    ok, error = ping_database()
    return {'status': 'ok' if ok else 'error', 'database_error': error}


@app.get('/leaderboard', response_class=HTMLResponse)
async def leaderboard(request: Request, search: str = '', limit: int = 100):
    db_error = None
    players = []

    try:
        players = fetch_leaderboard(search=search, limit=limit)
    except Exception as exc:
        db_error = str(exc)

    return templates.TemplateResponse(
        'leaderboard.html',
        {
            'request': request,
            'page_title': 'Global Rating',
            'active_page': 'leaderboard',
            'players': players,
            'search': search,
            'limit': limit,
            'db_error': db_error,
        },
    )



@app.get('/reports', response_class=HTMLResponse)
@app.get('/players', response_class=HTMLResponse)
async def game_reports(request: Request, search: str = '', limit: int = 100):
    db_error = None
    matches = []

    try:
        matches = fetch_game_reports(search=search, limit=limit)
    except Exception as exc:
        db_error = str(exc)

    return templates.TemplateResponse(
        'game_reports.html',
        {
            'request': request,
            'page_title': 'Game Reports',
            'active_page': 'reports',
            'matches': matches,
            'search': search,
            'limit': limit,
            'db_error': db_error,
        },
    )


@app.get('/players/{player_id}', response_class=HTMLResponse)
async def player_profile(request: Request, player_id: int):
    db_error = None
    profile = None

    try:
        profile = fetch_player_profile(player_id)
    except Exception as exc:
        db_error = str(exc)

    if db_error:
        return templates.TemplateResponse(
            'player_profile.html',
            {
                'request': request,
                'page_title': 'Player Profile',
                'active_page': 'players',
                'player': None,
                'recent_matches': [],
                'rating_chart': None,
                'db_error': db_error,
            },
            status_code=500,
        )

    if not profile:
        return templates.TemplateResponse(
            'player_profile.html',
            {
                'request': request,
                'page_title': 'Player Not Found',
                'active_page': 'players',
                'player': None,
                'recent_matches': [],
                'rating_chart': None,
                'db_error': None,
            },
            status_code=404,
        )

    return templates.TemplateResponse(
        'player_profile.html',
        {
            'request': request,
            'page_title': f"{profile['player']['name']} – Player Profile",
            'active_page': 'players',
            'player': profile['player'],
            'recent_matches': profile['recent_matches'],
            'rating_chart': profile.get('rating_chart'),
            'db_error': None,
        },
    )


@app.get('/submit', response_class=HTMLResponse)
async def submit_result(request: Request):
    return _render_submit_page(request)


@app.post('/submit', response_class=HTMLResponse)
async def submit_result_post(request: Request):
    raw_body = (await request.body()).decode('utf-8')
    parsed_body = parse_qs(raw_body, keep_blank_values=True)
    form_state = {key: values[-1] if values else '' for key, values in parsed_body.items()}

    try:
        success_data = submit_match_result(
            winner_name=form_state.get('winner_name', ''),
            opponent_name=form_state.get('opponent_name', ''),
            winner_race=form_state.get('winner_race', ''),
            opponent_race=form_state.get('opponent_race', ''),
            is_ranked=form_state.get('is_ranked', 'yes'),
            game_type=form_state.get('game_type', ''),
            mission_name=form_state.get('mission_name', ''),
            comment=form_state.get('comment', ''),
        )
    except Exception as exc:
        return _render_submit_page(
            request,
            form_state=form_state,
            error_message=str(exc),
            status_code=400,
        )

    return _render_submit_page(
        request,
        form_state=None,
        success_data=success_data,
        status_code=200,
    )

@app.get('/admin', response_class=HTMLResponse)
async def admin(request: Request):
    return templates.TemplateResponse(
        'placeholder.html',
        {
            'request': request,
            'page_title': 'Admin Panel',
            'active_page': 'admin',
            'title': 'Admin Panel',
            'text': 'This page will be used for match corrections, exports and rating recalculation.',
        },
    )
