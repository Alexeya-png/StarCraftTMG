`supporter-planet.svg` is the active TMG Stats supporter emblem used throughout the site.
