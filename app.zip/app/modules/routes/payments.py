from __future__ import annotations

import os
from datetime import datetime, timezone

from flask import Blueprint, current_app, jsonify, redirect, render_template, request

from app.database import (
    confirm_supporter_payment,
    fetch_player_name_suggestions,
    fetch_support_payment_by_session,
    fetch_user_account,
    resolve_existing_player_for_support,
)
from app.modules.auth import current_user_session
from app.modules.context import base_context, build_absolute_url

bp = Blueprint('payments', __name__)

SUPPORT_AMOUNTS_EUR = (2, 5, 10)


def _stripe_secret_key() -> str:
    return (os.getenv('STRIPE_SECRET_KEY') or '').strip()


def _stripe_webhook_secret() -> str:
    return (os.getenv('STRIPE_WEBHOOK_SECRET') or '').strip()


def _stripe_value(source, key: str, default=None):
    if source is None:
        return default
    if isinstance(source, dict):
        return source.get(key, default)
    return getattr(source, key, default)


def _stripe_metadata(session) -> dict:
    metadata = _stripe_value(session, 'metadata', {}) or {}
    try:
        return dict(metadata)
    except (TypeError, ValueError):
        return {}


def _stripe_customer_email(session) -> str:
    customer_details = _stripe_value(session, 'customer_details', {}) or {}
    return str(_stripe_value(customer_details, 'email', '') or '').strip()


def _stripe_payment_intent_id(session) -> str:
    payment_intent = _stripe_value(session, 'payment_intent', '')
    if isinstance(payment_intent, str):
        return payment_intent.strip()
    return str(_stripe_value(payment_intent, 'id', '') or '').strip()


def _stripe_confirmed_at() -> str:
    return datetime.now(timezone.utc).isoformat()


def _confirm_paid_checkout_session(session) -> dict | None:
    if str(_stripe_value(session, 'payment_status', '') or '').strip().lower() != 'paid':
        return None

    metadata = _stripe_metadata(session)
    if str(metadata.get('purpose') or '') != 'tmg_stats_support':
        raise ValueError('Unexpected Stripe Checkout purpose.')

    session_id = str(_stripe_value(session, 'id', '') or '').strip()
    player_id = int(str(metadata.get('player_id') or '0') or '0')
    account_id = int(str(metadata.get('account_id') or '0') or '0') or None
    metadata_amount_eur = int(str(metadata.get('amount_eur') or '0') or '0')
    amount_total = int(_stripe_value(session, 'amount_total', 0) or 0)
    currency = str(_stripe_value(session, 'currency', '') or '').strip().lower()
    if not session_id or player_id <= 0:
        raise ValueError('Stripe Checkout is missing the selected player.')
    if metadata_amount_eur not in SUPPORT_AMOUNTS_EUR or amount_total != metadata_amount_eur * 100:
        raise ValueError('Stripe Checkout amount does not match its metadata.')

    return confirm_supporter_payment(
        checkout_session_id=session_id,
        payment_intent_id=_stripe_payment_intent_id(session),
        player_id=player_id,
        account_id=account_id,
        amount_total=amount_total,
        currency=currency,
        customer_email=_stripe_customer_email(session),
        confirmed_at=_stripe_confirmed_at(),
    )


def _load_account_and_player() -> tuple[dict | None, dict | None]:
    user = current_user_session()
    if not user:
        return None, None

    try:
        account = fetch_user_account(int(user['account_id']), include_player_extras=False)
    except Exception:
        current_app.logger.exception('Could not load the signed-in supporter account')
        return None, None
    return account, (account or {}).get('player')


def _resolve_success_award(session_id: str) -> tuple[dict | None, bool]:
    clean_session_id = str(session_id or '').strip()
    if not clean_session_id:
        return None, False

    try:
        payment = fetch_support_payment_by_session(clean_session_id)
        if payment and payment.get('player'):
            player = payment['player']
            return {
                'player_id': int(player.get('id') or payment.get('player_id') or 0),
                'player_name': str(player.get('name') or ''),
                'supporter_since': str(player.get('supporter_since') or payment.get('confirmed_at') or ''),
                'already_recorded': True,
            }, False
    except Exception:
        current_app.logger.exception('Could not load the supporter payment result')

    if not _stripe_secret_key():
        return None, True

    try:
        from stripe import StripeClient

        client = StripeClient(_stripe_secret_key(), max_network_retries=2)
        stripe_session = client.v1.checkout.sessions.retrieve(clean_session_id)
        award = _confirm_paid_checkout_session(stripe_session)
        return award, award is None
    except Exception:
        current_app.logger.exception('Could not confirm the supporter badge from Stripe Checkout')
        return None, True


def _render_support_page(
    *,
    error_message: str | None = None,
    form_player_name: str = '',
    status_code: int = 200,
):
    payment_status = str(request.args.get('status') or '').strip().lower()
    if payment_status not in {'success', 'cancelled'}:
        payment_status = None

    account, linked_player = _load_account_and_player()
    name_suggestions: list[str] = []
    if not linked_player:
        try:
            name_suggestions = fetch_player_name_suggestions(limit=500)
        except Exception:
            current_app.logger.exception('Could not load support player suggestions')

    award = None
    award_pending = False
    if payment_status == 'success':
        award, award_pending = _resolve_success_award(request.args.get('session_id', ''))

    context = base_context(
        'Support TMG Stats',
        'support',
        meta_description='Support the hosting and continued development of the unofficial TMG Stats fan project.',
        canonical_path='/support',
        meta_robots='noindex,follow',
    )
    context.update(
        {
            'support_amounts': SUPPORT_AMOUNTS_EUR,
            'stripe_enabled': bool(_stripe_secret_key() and _stripe_webhook_secret()),
            'payment_status': payment_status,
            'error_message': error_message,
            'support_account': account,
            'linked_player': linked_player,
            'player_name': form_player_name,
            'name_suggestions': name_suggestions,
            'award': award,
            'award_pending': award_pending,
        }
    )
    return render_template('support.html', **context), status_code


@bp.route('/support', methods=['GET'])
def support_page():
    return _render_support_page()


@bp.route('/support/checkout', methods=['POST'])
def create_support_checkout():
    amount_eur = request.form.get('amount', type=int)
    player_name = str(request.form.get('player_name') or '').strip()
    if amount_eur not in SUPPORT_AMOUNTS_EUR:
        return _render_support_page(
            error_message='Please choose one of the available support amounts.',
            form_player_name=player_name,
            status_code=400,
        )

    secret_key = _stripe_secret_key()
    if not secret_key or not _stripe_webhook_secret():
        return _render_support_page(
            error_message='Stripe Checkout and automatic badge delivery are not configured yet. Please try again later.',
            form_player_name=player_name,
            status_code=503,
        )

    account, linked_player = _load_account_and_player()
    try:
        selected_player = linked_player or resolve_existing_player_for_support(player_name)
    except Exception as exc:
        return _render_support_page(
            error_message=str(exc),
            form_player_name=player_name,
            status_code=400,
        )

    player_id = int(selected_player.get('id') or 0)
    selected_player_name = str(selected_player.get('name') or '').strip()
    account_id = int((account or {}).get('id') or 0)
    metadata = {
        'purpose': 'tmg_stats_support',
        'amount_eur': str(amount_eur),
        'player_id': str(player_id),
        'player_name': selected_player_name,
        'account_id': str(account_id or ''),
    }

    session_payload = {
        'mode': 'payment',
        'locale': 'auto',
        'client_reference_id': f'player:{player_id}',
        'success_url': build_absolute_url('/support?status=success&session_id={CHECKOUT_SESSION_ID}'),
        'cancel_url': build_absolute_url('/support?status=cancelled'),
        'line_items': [
            {
                'price_data': {
                    'currency': 'eur',
                    'unit_amount': amount_eur * 100,
                    'product_data': {
                        'name': 'Support TMG Stats',
                        'description': f'One-time project support with a supporter badge for {selected_player_name}.',
                    },
                },
                'quantity': 1,
            }
        ],
        'metadata': metadata,
        'payment_intent_data': {'metadata': metadata},
    }
    if account and account.get('email'):
        session_payload['customer_email'] = str(account['email'])

    try:
        from stripe import StripeClient

        client = StripeClient(secret_key, max_network_retries=2)
        session = client.v1.checkout.sessions.create(session_payload)
    except ImportError:
        current_app.logger.exception('Stripe Python package is not installed')
        return _render_support_page(
            error_message='Stripe Checkout is temporarily unavailable.',
            form_player_name=player_name,
            status_code=503,
        )
    except Exception:
        current_app.logger.exception('Stripe Checkout session creation failed')
        return _render_support_page(
            error_message='Could not open Stripe Checkout. Please try again in a moment.',
            form_player_name=player_name,
            status_code=502,
        )

    checkout_url = str(_stripe_value(session, 'url', '') or '')
    if not checkout_url.startswith('https://checkout.stripe.com/'):
        current_app.logger.error('Stripe returned an invalid Checkout URL')
        return _render_support_page(
            error_message='Could not open Stripe Checkout. Please try again in a moment.',
            form_player_name=player_name,
            status_code=502,
        )

    return redirect(checkout_url, code=303)


@bp.route('/api/stripe/webhook', methods=['POST'])
def stripe_webhook():
    webhook_secret = _stripe_webhook_secret()
    if not webhook_secret:
        return jsonify({'ok': False, 'error': 'Stripe webhook is not configured.'}), 503

    signature = request.headers.get('Stripe-Signature', '')
    try:
        from stripe import Webhook

        event = Webhook.construct_event(request.get_data(), signature, webhook_secret)
    except Exception:
        return jsonify({'ok': False, 'error': 'Invalid Stripe signature.'}), 400

    event_type = str(_stripe_value(event, 'type', '') or '')
    if event_type not in {'checkout.session.completed', 'checkout.session.async_payment_succeeded'}:
        return jsonify({'ok': True, 'ignored': True})

    data = _stripe_value(event, 'data', {}) or {}
    stripe_session = _stripe_value(data, 'object', {}) or {}
    try:
        award = _confirm_paid_checkout_session(stripe_session)
    except Exception:
        current_app.logger.exception('Stripe webhook could not award the supporter badge')
        return jsonify({'ok': False, 'error': 'Could not award supporter badge.'}), 500

    if award is None:
        return jsonify({'ok': True, 'pending': True})
    return jsonify({'ok': True, 'award': award})
