from __future__ import annotations

import ipaddress
import threading
import time
from collections import defaultdict, deque

from flask import jsonify, make_response, request


_RATE_LIMIT_LOCK = threading.Lock()
_RATE_LIMIT_EVENTS: dict[tuple[str, str], deque[float]] = defaultdict(deque)
_LAST_GLOBAL_CLEANUP = 0.0


def _valid_ip(value: str | None) -> str:
    clean_value = str(value or '').strip()
    if not clean_value:
        return ''
    try:
        return str(ipaddress.ip_address(clean_value))
    except ValueError:
        return ''


def client_ip_address() -> str:
    cloudflare_ip = _valid_ip(request.headers.get('CF-Connecting-IP'))
    if cloudflare_ip:
        return cloudflare_ip

    forwarded_for = str(request.headers.get('X-Forwarded-For') or '').strip()
    if forwarded_for:
        forwarded_ip = _valid_ip(forwarded_for.split(',', 1)[0])
        if forwarded_ip:
            return forwarded_ip

    return _valid_ip(request.remote_addr) or 'unknown'


def _cleanup_old_buckets(now: float) -> None:
    global _LAST_GLOBAL_CLEANUP
    if now - _LAST_GLOBAL_CLEANUP < 300:
        return
    _LAST_GLOBAL_CLEANUP = now

    stale_before = now - 7200
    for key, events in list(_RATE_LIMIT_EVENTS.items()):
        while events and events[0] <= stale_before:
            events.popleft()
        if not events:
            _RATE_LIMIT_EVENTS.pop(key, None)


def consume_rate_limit(scope: str, *, limit: int, window_seconds: int) -> tuple[bool, int]:
    if limit <= 0 or window_seconds <= 0:
        return True, 0

    now = time.monotonic()
    cutoff = now - window_seconds
    bucket_key = (scope, client_ip_address())

    with _RATE_LIMIT_LOCK:
        _cleanup_old_buckets(now)
        events = _RATE_LIMIT_EVENTS[bucket_key]
        while events and events[0] <= cutoff:
            events.popleft()

        if len(events) >= limit:
            retry_after = max(1, int(window_seconds - (now - events[0])) + 1)
            return False, retry_after

        events.append(now)
        return True, 0


def rate_limit_response(retry_after: int):
    if request.path.startswith('/api'):
        response = jsonify(
            {
                'ok': False,
                'error': 'Too many requests. Please try again later.',
                'retry_after': retry_after,
            }
        )
        response.status_code = 429
    else:
        response = make_response('Too many requests. Please try again later.', 429)
    response.headers['Retry-After'] = str(retry_after)
    return response
